function scroll(){
	if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
		document.getElementById('scroll_nav').style.top = '0';
	} else {
		document.getElementById('scroll_nav').style.top = '-100px';
	}
}
window.onscroll = function() {scroll()};

$(document).ready(function() {
	$("#request").click(function(){
		$("#show_request").fadeToggle();
	});
});